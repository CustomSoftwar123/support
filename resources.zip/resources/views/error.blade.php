<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
  <link rel="shortcut icon" type="image/x-icon" href="{{ asset('images/' . \App\Http\Controllers\business::businessinfo()[0]->file) }}"/>
  <link href="{{ asset('plugins/fontawesome-free/css/all.min.css?1112') }}" rel="stylesheet" >
  <link href="{{ asset('plugins/ionicons.min.css') }}" rel="stylesheet" >
  <link href="{{ asset('dist/css/adminlte.css?1114') }}" rel="stylesheet" >
  <link href="{{ asset('css/icons.css?1112') }}" rel="stylesheet">
  <link href="{{ asset('plugins/notifications/css/lobibox.min.css?1112') }}" rel="stylesheet"/>
  <link rel="stylesheet" href="{{ asset('plugins/icheck-bootstrap/icheck-bootstrap.min.css?1112') }}">
  <link href="{{ asset('plugins/datatables-bs4/css/dataTables.bootstrap4.min.css?1112') }}" rel="stylesheet" >
  <link href="{{ asset('plugins/datatables-responsive/css/responsive.bootstrap4.min.css?1112') }}" rel="stylesheet" >
  <link href="{{ asset('plugins/datatables-buttons/css/buttons.bootstrap4.min.css?1112') }}" rel="stylesheet" >
  <link href="{{ asset('plugins/select2/css/select2.min.css?1112') }}" rel="stylesheet" >
  <link href="{{ asset('plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css?1112') }}" rel="stylesheet" >
  <link rel="stylesheet" href="{{ asset('plugins/fancy-file-uploader/fancy_fileupload.css?1112') }}" />
  <link href="{{ asset('plugins/daterangepicker/daterangepicker.css?1112') }}" rel="stylesheet" >
  <link href="{{ asset('plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css?1112') }}" rel="stylesheet" >
  <link href="{{ asset('plugins/bootstrap4-duallistbox/bootstrap-duallistbox.min.css?1112') }}" rel="stylesheet" >
  <link href="{{ asset('plugins/bs-stepper/css/bs-stepper.min.css?1112') }}" rel="stylesheet" >
  <link href="{{ asset('css/custom.css?1128') }}" rel="stylesheet"/>
</head>

<body class="bg-dark text-center">
  
<i class="fas fa-exclamation-triangle	 text-secondary" style="font-size:100px; margin-top:15%;"></i>
<h3 class="text-secondary mt-3">THIS PAGE IS ALREADY OPENED ON ANOTHER TAB !</h3>

</body>
</html>